package 문자열;

public class Test {

	public static void main(String[] args) {
		Integer x = 100;
		int x2 = x;
		
	}

}
