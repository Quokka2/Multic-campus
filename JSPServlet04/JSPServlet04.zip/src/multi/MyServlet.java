package multi;

import javax.servlet.http.HttpServlet;

public class MyServlet extends HttpServlet {

}
