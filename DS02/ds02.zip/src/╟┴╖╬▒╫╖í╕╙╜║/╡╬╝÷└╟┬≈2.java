package 프로그래머스;

public class 두수의차2 {

	public static void main(String[] args) {
//		int num1 = 2;
//		int num2 = 3;
//		
//		if (num1 == num2) {
//			System.out.println(1);
//		}
//		System.out.println(-1);
		
		double[] arr = {1,2,3,4};
		double sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum += arr[i];
		}
		System.out.println(sum/arr.length);
	}
}

