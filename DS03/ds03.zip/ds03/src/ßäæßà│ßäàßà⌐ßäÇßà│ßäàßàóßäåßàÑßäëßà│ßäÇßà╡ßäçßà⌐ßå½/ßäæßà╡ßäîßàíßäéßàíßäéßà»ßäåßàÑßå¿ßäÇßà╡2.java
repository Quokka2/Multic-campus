package 프로그래머스기본;

public class 피자나눠먹기2 {

	public static void main(String[] args) {
		int n = 12;
		int slice = 4;
		Solution4 sol = new Solution4();
		int answer = sol.solution(slice, n);
		System.out.println(answer);
	}
}

class Solution4 {
	public int solution(int slice, int n) {
		int answer = 0; // 주문할 피자수

		return answer;
	}
}