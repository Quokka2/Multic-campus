package com.multi.www.web04;

public class MainCar {

	public static void main(String[] args) {
		Car car = new Car("blue", 10000, 100);
		System.out.println(car);

	}

}
