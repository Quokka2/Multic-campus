package com.multi.www.web04;

public class Coffee2 {
	int price = 5000;
	String name = "핸드드립";
	public static Coffee2 c2; // null

	public static Coffee2 getInstance() {
		if (c2 == null) {
			c2 = new Coffee2();
		}
		return c2;
	}

	private Coffee2() {
	}
}
