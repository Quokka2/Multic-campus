package com.multi.mvc02;

public class MovieVO {
	private String movie;
	private int price;
	private int sum;

	public String getMovie() {
		return movie;
	}

	public void setMovie(String movie) {
		this.movie = movie;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	@Override
	public String toString() {
		return "MovieVO [movie=" + movie + ", price=" + price + ", sum=" + sum + "]";
	}

}
