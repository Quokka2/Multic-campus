package com.multi.mvc200;

public class Test2 {

	public static void main(String[] args) {
		
	}
}
