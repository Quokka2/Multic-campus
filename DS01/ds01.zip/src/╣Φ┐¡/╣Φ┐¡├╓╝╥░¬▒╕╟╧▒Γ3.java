package 배열;

import java.util.Arrays;
import java.util.Random;

public class 배열최소값구하기3 {

	public static void main(String[] args) {

		Random r = new Random(100);
		int[] num = new int[10];

		for (int i = 0; i < num.length; i++) {
			num[i] = r.nextInt(1000);
			System.out.println(num[i]);
		}
		Arrays.sort(num);

		System.out.println("최소 : " + num[0]);
		System.out.println("최대 : " + num[9]);

	}
}
