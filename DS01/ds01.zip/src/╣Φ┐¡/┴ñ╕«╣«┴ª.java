package 배열;

import java.util.Scanner;

public class 정리문제 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int[] num = new int[5];
		for (int i = 0; i < num.length; i++) {
			num[i] = sc.nextInt();
			if (num[0] > num[i]) {
				num[0] = num[i];
			}
		}
		sc.close();
		System.out.println(num[0]);
	}
}