package 배열;

public class 배열최소값구하기1 {

	public static void main(String[] args) {
		int[] s = { 90, 80, 20, 1, 60, 70, 100, 45, 10 };
		for (int i = 0; i < s.length; i++) {
			if (s[0] > s[i]) {
				s[0] = s[i];
			}
		}
		System.out.println("최소값은? " + s[0]);
	}
}
