package 배열;

import java.util.Random;

public class 정리문제2 {

	public static void main(String[] args) {
		Random r = new Random(20);
		int[] num = new int[20];
		for (int i = 0; i < num.length; i++) {
			num[i] = r.nextInt(900);
			if (num[0] < num[i]) {
				num[0] = num[i];
			}
			System.out.println(num[i]);
		}
		System.out.println("최대값 : " + num[0]);
	}
}