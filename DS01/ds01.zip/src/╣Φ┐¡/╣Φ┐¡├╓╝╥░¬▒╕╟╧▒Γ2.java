package 배열;

import java.util.Random;

public class 배열최소값구하기2 {

	public static void main(String[] args) {
		
		Random r = new Random(100);
		int[] num = new int[10];
		
		for (int i = 0; i < num.length; i++) {
			num[i] = r.nextInt(1000);
			if (num[0] < num[i]) {
				num[0] = num[i];
			}
		}
		System.out.println("최대값은? " + num[0]);
	}
}
