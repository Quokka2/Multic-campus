package 배열;

public class 정리문제3 {

	public static void main(String[] args) {
		String s1 = "참좋다";
		String s2 = "진짜좋다";
		System.out.println(s1.equals(s2));

		if (s1.length() > s2.length()) {
			System.out.println("s1이 더 많다.");
		}
		System.out.println("s2가 더 많다.");

		String s3 = "나는 진짜 java programmer가 되었어";
		System.out.println(s3.substring(6, 26));

		String s4 = "1056521";

		if (s4.charAt(0) == '2') {
			System.out.println("남자");
		} else {
			System.out.println("여자");
		}

	}
}