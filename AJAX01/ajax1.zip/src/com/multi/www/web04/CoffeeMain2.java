package com.multi.www.web04;

public class CoffeeMain2 {

	public static void main(String[] args) {
		
		Coffee2 c1 = Coffee2.getInstance();
		System.out.println(c1);

		Coffee2 c2;
		for (int i = 0; i < 10; i++) {
			c2 = Coffee2.getInstance();
			System.out.println(c2);
		}
	}
}
