package com.multi.www.web04;

public class MainCar3 {

	public static void main(String[] args) {
		Car2 car2;
		for (int i = 0; i < 10; i++) {
			car2 = Car2.getInstance();
			System.out.println(car2);
			car2.run();
		}
	}
}
