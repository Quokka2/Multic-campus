package com.multi.www.web04;

public class MainCar2 {

	public static void main(String[] args) {
		Car car;
		for (int i = 0; i < 10; i++) {
			car = new Car("blue" + i, 10000, 100);
			System.out.println(car);
		}
		System.out.println("메모리크기>>" + 12 * 100);
	}

}
