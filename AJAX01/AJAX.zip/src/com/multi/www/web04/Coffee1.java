package com.multi.www.web04;

public class Coffee1 {
	int price;
	String name;

	public Coffee1(int price, String name) {
		super();
		this.price = price;
		this.name = name;
	}
}
