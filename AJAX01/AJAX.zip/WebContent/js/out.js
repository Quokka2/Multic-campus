function login() {
	id2 = 'root';
	id = prompt('아이디 입력')
	if (id == id2) {
		alert('로그인 성공')
	}else {
		alert('땡!')		
	}
}

function com() {
	n1=prompt('비밀번호 입력')
	n2=prompt('비밀번호 확인')
	if (n1==n2) {
		alert('성공')
	} else {
		alert('땡!!')
	}
}

function sens() {
	s1 = prompt('기분 입력1')
	s2 = prompt('기분 입력2')
	if (s1==s2) {
		alert('일치')
	} else {
		alert('불일치')
	}
}