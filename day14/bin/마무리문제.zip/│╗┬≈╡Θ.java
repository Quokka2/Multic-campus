package 마무리문제;

public class 내차들 extends Object {

	public static void main(String[] args) {
		Car c1 = new Car();
		c1.brand();
		Truck t1 = new Truck();
		t1.truck();
		CoffeeTruck ct1 = new CoffeeTruck();
		ct1.Use();
	}
}
