package 마무리문제;

public class Truck extends Car{
	String kind;
	
	public void truck() {
		System.out.println("차량모델 : 벤");
	}
	
	
}
