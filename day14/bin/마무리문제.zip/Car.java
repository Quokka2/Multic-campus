package 마무리문제;

public class Car extends 내차들{
	String brand;
	
	public void brand() {
		System.out.println("브랜드 : 밴츠");
	}
	
	
}
