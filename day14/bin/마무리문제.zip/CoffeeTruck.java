package 마무리문제;

public class CoffeeTruck extends Truck {
	String use;
	String total;

	public void Use() {
		System.out.println("용도 : 커피차 배달");
	}
}