package com.multi.mvc300;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BookDAO {

	@Autowired
	SqlSessionTemplate my;

	public int insert(BookVO bag) {
		int result = my.insert("book.create", bag);
		return result;
	}

	public BookVO one(BookVO bag) {
		BookVO result = my.selectOne("book.one", bag);
		System.out.println(result);
		return result;
	}

	public List<Object> list() {
		return my.selectList("book.all");
	}
	
}