package com.multi.mvc300;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MusicController {
	
	@Autowired
	MusicDAO dao;
	
	@RequestMapping("insert5")
	public void insert5(MusicVO bag) {
		System.out.println(bag);
		System.out.println(dao);
		dao.insert(bag);
	}
	
	@RequestMapping("update5")
	public void update5(MusicVO bag) {
		dao.update(bag);
	}
	
	@RequestMapping("delete5")
	public void delete(int no) {
		dao.delete(no);
	}
	
	@RequestMapping("one6")
	public void one6(MusicVO bag, Model model) {
		MusicVO result = dao.one(bag);
		System.out.println(dao);
		model.addAttribute("bag", result);
	}
	
	@RequestMapping("list5")
	public void list(Model model) {
		List<Object> list = dao.list();
		model.addAttribute("list", list);
	}
}
