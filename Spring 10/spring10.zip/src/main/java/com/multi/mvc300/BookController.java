package com.multi.mvc300;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BookController {
	
	@Autowired
	BookDAO dao;
	
	@RequestMapping("insert3.multi")
	public void insert(BookVO bag) {
		System.out.println("insert요청됨.");
		System.out.println(bag);
		System.out.println(dao);
		dao.insert(bag);
	}
	
	@RequestMapping("one3.multi")
	public void one3(BookVO bag, Model model) {
		BookVO result = dao.one(bag);
		System.out.println(dao);
		model.addAttribute("bag", result);
	}
	
	@RequestMapping("list3.multi")
	public void list(Model model) {
		List<Object> list = dao.list();
		model.addAttribute("list", list);
	}
}
