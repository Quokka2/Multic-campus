package com.multi.mvc300;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MusicDAO {

	@Autowired
	SqlSessionTemplate my;

	public int insert(MusicVO bag) {
		int result = my.insert("music.create", bag);
		return result;
	}
	
	public int delete(int no) {
		int result = my.delete("music.del", no);
		return result;
	}

	public int update(MusicVO bag) {
		int result = my.update("music.up", bag);
		return result;
	}

	public MusicVO one(MusicVO bag) {
		MusicVO result = my.selectOne("music.one", bag);
		System.out.println(result);
		return result;
	}

	public List<Object> list() {
		return my.selectList("music.all");
	}
	
}