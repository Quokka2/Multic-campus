package com.multi.mvc01;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebtoonController {

	@Autowired
	WebtoonDAO dao;// 100

	@RequestMapping("insert4.multi")
	public void insert(WebtoonVO bag) {
		System.out.println("insert요청됨.");
		System.out.println(bag);
		System.out.println(dao);
		dao.insert(bag);
	}
	
//	@RequestMapping("update")
//	public void update(MemberVO bag) {
//		System.out.println("update요청됨.");
//		System.out.println(bag);
//		dao.update(bag);
//	}
//
//	@RequestMapping("delete")
//	public void delete(String id) {
//		System.out.println("delete요청됨.");
//		System.out.println(id);
//		dao.delete(id);
//	}
	
	@RequestMapping("one4.multi")
	public void one4(String id, Model model) {
		WebtoonVO bag = dao.one(id); // bag에 검색결과가 들어있을 것임.
		model.addAttribute("bag", bag);
	}

	@RequestMapping("list4.multi")
	public void list(Model model) {
		ArrayList<WebtoonVO> list = dao.list();
		model.addAttribute("list", list);
	}
}
